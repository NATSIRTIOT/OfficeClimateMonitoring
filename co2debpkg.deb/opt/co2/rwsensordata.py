import json
import subprocess # to be able run bash script in python script
import requests
import time
import paho.mqtt.client as mqtt

mqttClient = mqtt.Client("CO2-measurements")
broker = "localhost"
# used sources https://github.com/thin-edge/thin-edge.io_examples/blob/main/StreamingAnalytics/LimitedBandwidth/demo_publisher.py
def on_publish(client, userdata, result):
    pass

def on_connect(client, userdate, flags, rc):
    print("Connected to MQTT broker on " + broker + " with result {0}".format(rc))

mqttClient.on_connect = on_connect
mqttClient.on_publish = on_publish
mqttClient.connect(broker)

delay = 1
# send measurement  
while(True):
    # api-endpoint (cloud endpoint)
    API_ENDPOINT = "http://209.250.240.96:8080/sensordata/getSensorData"
    # dict
    data = { 
        "startDate": "07/04/2022 00:00:00",
	"endDate": "22/03/2023 00:00:00",
	"page": 0,
	"limit": 1,
	"deviceIds": ["FFFF00005001"],
	"needCount": False 
    }
    headers = {'Content-type': 'application/json'}
    # function which publishes a measurement to X
    #def tedge_publish_measurement(measurement):
    #	subprocess.run(["tedge","mqtt","pub","tedge/measurements", measurement])

    # sending post request and store response in a response object
    r = requests.post(url = API_ENDPOINT, json = data, headers = headers) #, headers=headers)
    # get json data from response object
    data = r.json() 
    print(data)

    # parse co2 value from json data
    co2_val = float(data['baseSensorOutputDataList'][0]['sensorData'][0]['value'])
    print(co2_val)
    # parse temperature value from json data
    temp_val = float(data['baseSensorOutputDataList'][0]['sensorData'][1]['value'])
    print(temp_val)
    # parse humidity value from json data
    hum_val = float(data['baseSensorOutputDataList'][0]['sensorData'][2]['value'])
    print(hum_val)
    # convert to thin edge json format
    #tjsonstring= '{ "CO2": %f }' % (co2_val)
    #print(tjsonstring)

    #tedge_publish_measurement(tjsonstring)
    event = {}
    event['co2'] = co2_val
    mqttClient.publish('sensors/co2', json.dumps(event, default=str))
    event['temperature'] = temp_val
    mqttClient.publish('sensors/temperature', json.dumps(event, default=str))
    event['humidity'] = hum_val
    mqttClient.publish('sensors/humidity', json.dumps(event, default=str))

    time.sleep(delay)
